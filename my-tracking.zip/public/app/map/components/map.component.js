System.register(["@angular/core", "../../services/TrackingService", "@agm/core", "jquery"], function (exports_1, context_1) {
    "use strict";
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __moduleName = context_1 && context_1.id;
    var core_1, TrackingService_1, core_2, jquery_1, MapComponent;
    return {
        setters: [
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (TrackingService_1_1) {
                TrackingService_1 = TrackingService_1_1;
            },
            function (core_2_1) {
                core_2 = core_2_1;
            },
            function (jquery_1_1) {
                jquery_1 = jquery_1_1;
            }
        ],
        execute: function () {
            MapComponent = (function () {
                function MapComponent(trackingService, _mapsAPILoader) {
                    this.trackingService = trackingService;
                    this._mapsAPILoader = _mapsAPILoader;
                    this.lat = 10.820751;
                    this.lng = 106.630894;
                    this.internalInterval = null;
                    this.isRoadmap = false;
                    this.isInit = false;
                    this.icon_roadmap = window['APP_URL'] + "/assets/images/$hd$-pin.png";
                    this.icon_roadmap_start = window['APP_URL'] + "/assets/images/start_pin.png";
                    this.icon_roadmap_end = window['APP_URL'] + "/assets/images/end_pin.png";
                    this.isSending = false;
                    //this.options = new DatePickerOptions();
                }
                ;
                MapComponent.prototype.ngAfterViewInit = function () {
                    var _this = this;
                    this._mapsAPILoader.load().then(function () {
                        // _this.mapBounds = new google.maps.LatLngBounds();
                        // _this.mapBounds.extend(new google.maps.LatLng({"lat" : _this.lat, "lng" : _this.lng}));
                    });
                };
                MapComponent.prototype.ngOnInit = function () {
                    this.requestLocation();
                    document.addEventListener('visibilitychange', function () {
                        document.title = document.hidden ? "hidden" : "active"; // change tab text for demo
                    });
                    this.date_from = new Date();
                    this.date_to = new Date();
                };
                ;
                MapComponent.prototype.requestLocation = function () {
                    var _this = this;
                    this.trackingService.getLocations(this.trackingService.urlLocation, this.lastPoint).
                        then(function (locationObj) {
                        // console.log(markers.length, 'location markers');
                        var keys = [];
                        if (locationObj !== undefined) {
                            if (_this.allMarkers === undefined) {
                                _this.allMarkers = locationObj.markers;
                            }
                            else {
                                keys = Object.keys(locationObj.markers);
                                for (var i = 0; i < keys.length; i++) {
                                    if (_this.allMarkers[keys[i]] !== undefined) {
                                        _this.allMarkers[keys[i]].locations = _this.allMarkers[keys[i]].locations
                                            .concat(locationObj.markers[keys[i]].locations);
                                    }
                                }
                            }
                            if (locationObj != null && locationObj.lastPoint !== undefined && locationObj.lastPoint != null) {
                                _this.lastPoint = locationObj.lastPoint;
                            }
                            if (!_this.isInit) {
                                keys = Object.keys(_this.allMarkers);
                                for (var i_1 = 0; i_1 < keys.length; i_1++) {
                                    var marker = _this.allMarkers[keys[i_1]];
                                    _this.handleLocation(marker, _this);
                                    if (_this.roadmapSelectedMarker === undefined) {
                                        //init the marker that choiceonDeviceSelected($event) on roadmap mode
                                        _this.roadmapSelectedMarker = marker;
                                    }
                                }
                                _this.isInit = true;
                            }
                            if (_this.internalInterval == null) {
                                _this.fetchMarkers(_this);
                            }
                            _this.isSending = false;
                        }
                    }, function (error) { });
                };
                MapComponent.prototype.fetchMarkers = function (context) {
                    //handler to markers
                    var _this = context;
                    _this.internalInterval = setInterval(function () {
                        var keys = Object.keys(_this.allMarkers);
                        for (var i = 0; i < keys.length; i++) {
                            var marker = _this.allMarkers[keys[i]];
                            _this.handleLocation(marker, _this);
                        }
                    }, 5000);
                };
                ;
                MapComponent.prototype.handleLocation = function (marker, context) {
                    /** handle for location */
                    if (context.mapBounds === undefined) {
                        context.mapBounds = new google.maps.LatLngBounds();
                    }
                    var locationsLenght = 0;
                    var keys = Object.keys(context.allMarkers);
                    for (var i = 0; i < keys.length; i++) {
                        var marker_1 = context.allMarkers[keys[i]];
                        locationsLenght = marker_1.locations.length;
                    }
                    if (marker.locations.length >= 1) {
                        var lt = marker.locations.shift();
                        marker.currentLocation = lt;
                        var coord = new google.maps.LatLng({ "lat": lt.lat, "lng": lt.lng });
                        if (context.mapBounds !== undefined) {
                            context.mapBounds.extend(coord);
                        }
                    }
                    else if (locationsLenght === 0 && !context.isSending) {
                        context.isSending = true;
                        context.requestLocation();
                    }
                };
                ;
                MapComponent.prototype.log = function (value) {
                    console.log(value);
                };
                MapComponent.prototype.toArray = function (data) {
                    var data_markers = data !== undefined ? data : this.allMarkers;
                    if (data_markers != null && data_markers !== undefined) {
                        var keys = Object.keys(data_markers);
                        var arrs = [];
                        for (var i = 0; i < keys.length; i++) {
                            var temp = data_markers[keys[i]];
                            arrs.push(temp);
                        }
                        return arrs;
                    }
                    else {
                        return [];
                    }
                };
                MapComponent.prototype.onMapReady = function ($event) {
                    if (this.mapRoadmapBounds === undefined) {
                        this.mapRoadmapBounds = new google.maps.LatLngBounds();
                    }
                    var height = jquery_1.default(window).height() - 120;
                    jquery_1.default('agm-map').css({ "height": height + "px" });
                    jquery_1.default('#control-section div.row.tab-pane').css({ "height": (height - 44) + "px" });
                    jquery_1.default('#control-section div.device-list').css({ "height": (height - 44 - 123) + "px" });
                    //init geocoder
                    this.geoCoder = new google.maps.Geocoder();
                };
                MapComponent.prototype.onSelected = function ($event) {
                    console.log($event, 'event marker emitted');
                };
                MapComponent.prototype.onChangeTab = function ($event) {
                    console.log($event);
                    var $target = jquery_1.default($event.target).attr('data-target');
                    jquery_1.default('li.tab.active').removeClass('active');
                    jquery_1.default($event.target).addClass('active');
                    jquery_1.default('div.row.tab-pane').addClass('hide');
                    jquery_1.default($target).removeClass('hide');
                    if ($target === '#real-time') {
                        this.isRoadmap = false;
                    }
                    else {
                        this.isRoadmap = true;
                    }
                };
                MapComponent.prototype.onViewRoadmap = function ($event) {
                    console.log($event);
                    var _this = this;
                    var options = {
                        "isRoadmap": true,
                        "dateFrom": this.formatDateTime(this.date_from),
                        "dateTo": this.formatDateTime(this.date_to),
                        "deviceId": this.roadmapSelectedMarker.deviceId
                    };
                    this.trackingService.getLocations(this.trackingService.urlLocation, null, options).
                        then(function (locationObj) {
                        if (locationObj.markers[_this.roadmapSelectedMarker.deviceId] === undefined) {
                            alert("Không có thông tin lộ trình!");
                            return false;
                        }
                        _this.roadmapMarkers = [];
                        _this.roadmapMarkers = locationObj.markers[_this.roadmapSelectedMarker.deviceId].locations;
                        _this.mapRoadmapBounds = new google.maps.LatLngBounds();
                        for (var i = 0; i < _this.roadmapMarkers.length; i++) {
                            var lt = _this.roadmapMarkers[i];
                            var coord = new google.maps.LatLng({ "lat": lt.lat, "lng": lt.lng });
                            if (_this.mapRoadmapBounds !== undefined) {
                                _this.mapRoadmapBounds.extend(coord);
                            }
                        }
                    }, function (error) { });
                };
                MapComponent.prototype.onDeviceSelected = function ($event) {
                    this.roadmapSelectedMarker = $event;
                };
                MapComponent.prototype.formatDateTime = function (date) {
                    var datetimeStr = "";
                    var year = date.getFullYear();
                    var month = ((date.getMonth() + 1) < 10 ? ("0" + (date.getMonth() + 1)) : (date.getMonth() + 1));
                    var dateStr = (date.getDate() < 10 ? "0" + (date.getDate()) : date.getDate());
                    var hour = (date.getHours() < 10 ? ("0" + date.getHours()) : date.getHours());
                    var minutes = (date.getMinutes() < 10 ? ("0" + date.getMinutes()) : date.getMinutes());
                    var second = (date.getSeconds() < 10 ? ("0" + date.getSeconds()) : date.getSeconds());
                    return year + '-' + month + '-' + dateStr + " " + hour + ":" + minutes + ":" + second;
                };
                MapComponent.prototype.onMarkerClick = function ($event, location) {
                    var latlng = {
                        "lat": location.lat,
                        "lng": location.lng
                    };
                    this.geoCoder.geocode({ 'location': latlng }, function (results, status) {
                        if (status === 'OK') {
                            if (results[0]) {
                                location.address = results[0].formatted_address;
                            }
                            else {
                                location.address = 'N/A';
                            }
                        }
                        else {
                            location.address = 'N/A';
                        }
                    });
                };
                MapComponent.prototype.getRoadmapPin = function (index, marker) {
                    var pin = this.icon_roadmap;
                    var img = '';
                    if (index === 0) {
                        img = this.icon_roadmap_start;
                    }
                    else if (index === (this.roadmapMarkers.length - 1)) {
                        img = this.icon_roadmap_end;
                    }
                    else {
                        img = this.icon_roadmap;
                        img = img.replace('$hd$', marker.headingClass);
                    }
                    return img;
                };
                MapComponent = __decorate([
                    core_1.Component({
                        selector: 'map',
                        templateUrl: './app/map/components/map.component.html',
                        styleUrls: ['./app/map/components/map.css'],
                    }),
                    __metadata("design:paramtypes", [TrackingService_1.TrackingService, core_2.MapsAPILoader])
                ], MapComponent);
                return MapComponent;
            }());
            exports_1("MapComponent", MapComponent);
            // create new class to handle all change of marker called cluster
            // each changing literal, market will be change current location so that their position on map will be changed 
        }
    };
});

//# sourceMappingURL=map.component.js.map
