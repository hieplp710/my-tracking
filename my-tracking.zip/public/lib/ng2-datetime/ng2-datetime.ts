export { NKDatetime } from './src/ng2-datetime/ng2-datetime';
export { NKDatetimeModule } from './src/ng2-datetime/ng2-datetime.module';
