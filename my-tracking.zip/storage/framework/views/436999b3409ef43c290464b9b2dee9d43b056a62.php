<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Test socket</div>

                    <div class="panel-body">
                        You are logged in!
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        var socket = new WebSocket("ws://127.0.0.1:8080");

        socket.onopen = function() {
            alert("The connection is established.");
        };

        socket.onclose = function(event) {
            if (event.wasClean) {
                alert('Connection closed cleanly');
            } else {
                alert('Broken connections');
            }
            alert('Key: ' + event.code + ' cause: ' + event.reason);
        };

        socket.onmessage = function(event) {
            alert("The data " + event.data);
        };

        socket.onerror = function(error) {
            alert("Error " + error.message);
        };


        //To send data using the method socket.send(data).

        //For example, the line:
        socket.send("Hello");
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>